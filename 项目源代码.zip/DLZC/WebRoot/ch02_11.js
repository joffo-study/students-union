﻿function validate(){
		
         var name=document.forms[0].userName.value;
         var pwd=document.forms[0].userPwd.value;
         var pwd1=document.forms[0].userPwd1.value;
        
         if(name.length<=0) alert("用户名不能为空！");
         else if(pwd.length>4 ||pwd.length<=3) alert("密码长度必须等于4！");
         else if(pwd!=pwd1) alert("两次密码不一致！"); 
         
         else document.forms[0].submit(); 
    } 
