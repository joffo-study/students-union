package com.dao;
import java.util.List;
import vo.*;
public interface IStudentDAO {

	public abstract List<Student> findS(Student stu) throws Exception;
	public boolean createS(Student stu) throws Exception;
}
