package com.dao;	
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.db.*;
import vo.Student;


public class StudentDAO implements IStudentDAO {
    
	public List<Student> findS(Student stu) throws Exception{
	
		Connection conn = null;
	 PreparedStatement prepStmt = null;
	 ResultSet rs=null;
	 Student stu2=null;
	 List<Student> student =new ArrayList<Student>();
	 conn=DbConnect.getDBconnection();
	 String sql="select distinct Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Zxiehui from student where Sname=? or Xibie=?";
	 prepStmt = conn.prepareStatement(sql);
	 prepStmt.setString(1,stu.getSname());
	prepStmt.setString(2,stu.getXibie());
	 
	 rs=prepStmt.executeQuery();
	 
	 while(rs.next()){
		 stu2=new Student();
		 stu2.setSid(rs.getInt(1));
		 stu2.setSname(rs.getString(2));
		 stu2.setShouji(rs.getString(3));
		 stu2.setWeixin(rs.getString(4));
		 stu2.setXibie(rs.getString(5));
		 stu2.setZname(rs.getString(6));
		 stu2.setZbumen(rs.getString(7));
		 stu2.setZxiehui(rs.getString(8));
		 student.add(stu2);
	 }
	 DbConnect.closeDB(conn, prepStmt, rs);
	 return student;
}
	
	public List<Student> findXS(Student stu) throws Exception{    //查找协会里面的全部成员
		
		Connection conn = null;
	 PreparedStatement prepStmt = null;
	 ResultSet rs=null;
	 Student stu2=null;
	 List<Student> student =new ArrayList<Student>();
	 conn=DbConnect.getDBconnection();
	 String sql="select Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Zxiehui from student where Zxiehui=? or Zbumen=? or Zname=?";
	 prepStmt = conn.prepareStatement(sql);
	 prepStmt.setString(1,stu.getZxiehui());
	prepStmt.setString(2,stu.getZbumen());
	prepStmt.setString(3,stu.getZname());
	 
	 rs=prepStmt.executeQuery();
	 
	 while(rs.next()){
		 stu2=new Student();
		 stu2.setSid(rs.getInt(1));
		 stu2.setSname(rs.getString(2));
		 stu2.setShouji(rs.getString(3));
		 stu2.setWeixin(rs.getString(4));
		 stu2.setXibie(rs.getString(5));
		 stu2.setZname(rs.getString(6));
		 stu2.setZbumen(rs.getString(7));
		 stu2.setZxiehui(rs.getString(8));
		 student.add(stu2);
	 }
	 DbConnect.closeDB(conn, prepStmt, rs);
	 return student;
}
	
	public boolean createS(Student stu) throws Exception{
		Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs=null;
		 int count=0;

		 try {
			 conn = DbConnect.getDBconnection();
			 
			 String sql="insert into student(Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Zxiehui,Sduiwu,Sduixie) values(?,?,?,?,?,?,?,?,?,?)";
			 ps = conn.prepareStatement(sql);
			 ps.setInt(1,stu.getSid());
			 ps.setString(2,stu.getSname());
			 ps.setString(3,stu.getShouji());
			 ps.setString(4,stu.getWeixin());
			 ps.setString(5,stu.getXibie());
			 ps.setString(6,stu.getZname());
			 ps.setString(7,stu.getZbumen());
			 ps.setString(8,stu.getZxiehui());
			 ps.setString(9,stu.getSduiwu());
			 ps.setString(10,stu.getSduixie());
			
			count=ps.executeUpdate();
			
		 }finally {DbConnect.closeDB(conn,ps,rs);}
		 if(count>0) return true;
		 else return false;
	   }
	
	public boolean removeXS(int sid) throws Exception{
		Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs=null;
		 int n=0;
		 try{
			 conn = DbConnect.getDBconnection();
			 String sql="delete from student where Sid=?";
			 ps = conn.prepareStatement(sql);
			 ps.setInt(1,sid);
			 n=ps.executeUpdate();
		 }catch(Exception e){
		 
		 }finally{
			 DbConnect.closeDB(conn,ps, rs);
		 }if(n>=1) return true;
		 else return false;
	}
	
	public boolean updateXS(Student stu) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int rowCount=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	String sql = "update student set Sname=?,Shouji=?,Weixin=?,Xibie=?,Zname=?,Zbumen=?,Zxiehui=? where Sid=? ";
         prepStmt = con.prepareStatement(sql);
         
         //prepStmt.setInt(1, stu.getId());
         prepStmt.setString(1,stu.getSname());
         prepStmt.setString(2,stu.getShouji());
         prepStmt.setString(3,stu.getWeixin());
         prepStmt.setString(4,stu.getXibie());
         prepStmt.setString(5,stu.getZname());
         prepStmt.setString(6,stu.getZbumen());
         prepStmt.setString(7,stu.getZxiehui());
         prepStmt.setInt(8, stu.getSid());
		 rowCount=prepStmt.executeUpdate();
		 
            if (rowCount == 0) {
                   throw new Exception("Update Error:Student Id:" + stu.getSid());
            }
        } catch (Exception e) {
                e.printStackTrace();
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }if(rowCount!=0)  {return true;}
        else 
        	{ return false;}
}
	
	public boolean updateUnion(Student stu) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int rowCount=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	String sql = "update student set Sname=?,Shouji=?,Weixin=?,Xibie=?,Zname=?,Zbumen=?,Zxiehui=?,Sduiwu=?,Sduixie=? where Sid=? ";
         prepStmt = con.prepareStatement(sql);
         
         //prepStmt.setInt(1, stu.getId());
         prepStmt.setString(1,stu.getSname());
         prepStmt.setString(2,stu.getShouji());
         prepStmt.setString(3,stu.getWeixin());
         prepStmt.setString(4,stu.getXibie());
         prepStmt.setString(5,stu.getZname());
         prepStmt.setString(6,stu.getZbumen());
         prepStmt.setString(7,stu.getZxiehui());
         prepStmt.setString(8,stu.getSduiwu());
         prepStmt.setString(9,stu.getSduixie());
         prepStmt.setInt(10, stu.getSid());
		 rowCount=prepStmt.executeUpdate();
		 
            if (rowCount == 0) {
                   throw new Exception("Update Error:Student Id:" + stu.getSid());
            }
        } catch (Exception e) {
                e.printStackTrace();
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }if(rowCount!=0)  {return true;}
        else 
        	{ return false;}
}
	
	public List<Student> findUnion() throws Exception{
		Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs=null;
		 List<Student> student =new ArrayList<Student>();
		 conn=DbConnect.getDBconnection();
		 String sql="select Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Sduixie,Sduiwu,Zxiehui from student where Zxiehui='联合会'";
		 ps = conn.prepareStatement(sql);
		 rs=ps.executeQuery();
		 
		 while(rs.next()){
			 Student stu2=new Student();
			 stu2.setSid(rs.getInt(1));
			 stu2.setSname(rs.getString(2));
			 stu2.setShouji(rs.getString(3));
			 stu2.setWeixin(rs.getString(4));
			 stu2.setXibie(rs.getString(5));
			 stu2.setZname(rs.getString(6));
			 stu2.setZbumen(rs.getString(7));
			 stu2.setSduixie(rs.getString(8));
			 stu2.setSduiwu(rs.getString(9));
			 stu2.setZxiehui(rs.getString(10));
			
			 student.add(stu2);
		 }
		 DbConnect.closeDB(conn, ps, rs);
		 return student;
	}
	
public List<Student> findX_S(String xname) throws Exception{    //查找协会里面的管理人员
		
		Connection conn = null;
	 PreparedStatement prepStmt = null;
	 ResultSet rs=null;
	 Student stu2=null;
	 List<Student> student =new ArrayList<Student>();
	 conn=DbConnect.getDBconnection();
	 String sql="select Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Zxiehui from student where Zxiehui=? and (Zname='会长' or Zname='副会长' or Zname='部长')";
	 prepStmt = conn.prepareStatement(sql);
	 prepStmt.setString(1,xname);
	 
	 rs=prepStmt.executeQuery();
	 
	 while(rs.next()){
		 stu2=new Student();
		 stu2.setSid(rs.getInt(1));
		 stu2.setSname(rs.getString(2));
		 stu2.setShouji(rs.getString(3));
		 stu2.setWeixin(rs.getString(4));
		 stu2.setXibie(rs.getString(5));
		 stu2.setZname(rs.getString(6));
		 stu2.setZbumen(rs.getString(7));
		 stu2.setZxiehui(rs.getString(8));
		 student.add(stu2);
	 }
	 DbConnect.closeDB(conn, prepStmt, rs);
	 return student;
}

public List<Student> findX_S1(String xname) throws Exception{    //查找协会里面的管理人员
	
	Connection conn = null;
 PreparedStatement prepStmt = null;
 ResultSet rs=null;
 Student stu2=null;
 List<Student> student =new ArrayList<Student>();
 conn=DbConnect.getDBconnection();
 String sql="select Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Zxiehui from student where Zxiehui=? ";
 prepStmt = conn.prepareStatement(sql);
 prepStmt.setString(1,xname);
 
 rs=prepStmt.executeQuery();
 
 while(rs.next()){
	 stu2=new Student();
	 stu2.setSid(rs.getInt(1));
	 stu2.setSname(rs.getString(2));
	 stu2.setShouji(rs.getString(3));
	 stu2.setWeixin(rs.getString(4));
	 stu2.setXibie(rs.getString(5));
	 stu2.setZname(rs.getString(6));
	 stu2.setZbumen(rs.getString(7));
	 stu2.setZxiehui(rs.getString(8));
	 student.add(stu2);
 }
 DbConnect.closeDB(conn, prepStmt, rs);
 return student;
}

public List<Student> findX_fu(String sduixie) throws Exception{    //查找协会里面的负责人员
	
	Connection conn = null;
 PreparedStatement prepStmt = null;
 ResultSet rs=null;
 Student stu2=null;
 List<Student> student =new ArrayList<Student>();
 conn=DbConnect.getDBconnection();
 String sql="select Sid,Sname,Shouji,Weixin,Xibie,Zname,Zbumen,Zxiehui,Sduiwu,Sduixie from student where Sduixie=?";
 prepStmt = conn.prepareStatement(sql);
 prepStmt.setString(1,sduixie);
 
 rs=prepStmt.executeQuery();
 
 while(rs.next()){
	 stu2=new Student();
	 stu2.setSid(rs.getInt(1));
	 stu2.setSname(rs.getString(2));
	 stu2.setShouji(rs.getString(3));
	 stu2.setWeixin(rs.getString(4));
	 stu2.setXibie(rs.getString(5));
	 stu2.setZname(rs.getString(6));
	 stu2.setZbumen(rs.getString(7));
	 stu2.setZxiehui(rs.getString(8));
	 stu2.setSduiwu(rs.getString(9));
	 stu2.setSduixie(rs.getString(10));
	 student.add(stu2);
 }
 DbConnect.closeDB(conn, prepStmt, rs);
 return student;
}
}