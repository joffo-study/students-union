package com.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.db.DbConnect;

import vo.*;
public class User {
	protected static final String FIELDS_INSERT ="name,pwd";
	
	protected static String SELECT_SQL="select "
                                    +FIELDS_INSERT+" from user_a where name=?";
	protected static String INSERT_SQL="insert into user_a ("
	        +FIELDS_INSERT+")"+"values (?,?)";
	protected static String DELETE_SQL ="delete from user_a where name=?";
	public yonghu insert(yonghu y) throws Exception{
		 Connection con=null;
	      PreparedStatement prepStmt=null;
	      ResultSet rs=null;
	      try{
	    	  con=DbConnect.getDBconnection();
	    	  prepStmt =con.prepareStatement(INSERT_SQL); 
	    	  prepStmt.setString(1,y.getName());
	    	  prepStmt.setString(2,y.getPwd());
	    	 
	          prepStmt.executeUpdate();
	      } catch(Exception e){
	      } finally{
	    	     DbConnect.closeDB(con, prepStmt, rs);
	      }
	      return y;
}
	/*public boolean delete(yonghu y) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int n=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	prepStmt = con.prepareStatement(DELETE_SQL);
	        prepStmt.setString(1,y.getName());
	        n=prepStmt.executeUpdate();
	    }catch(Exception e) {
	          
	    } finally{
	    	 DbConnect.closeDB(con, prepStmt, rs);
	    }if(n>=1) return true;
	    else return false;
	}*/
	public yonghu find(yonghu y) throws Exception {
	    Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    yonghu stu2 = null;
	    try {
	       con=DbConnect.getDBconnection();
            prepStmt = con.prepareStatement(SELECT_SQL);
            prepStmt.setString(1, y.getName());
            rs = prepStmt.executeQuery();
            
            if (rs.next()){
            	stu2 = new yonghu();
                stu2.setName(rs.getString(1)); 
                stu2.setPwd(rs.getString(2));
           }
      } catch (Exception e) {
          // handle exception
      } finally {
    	     DbConnect.closeDB(con, prepStmt, rs);
      }
     return stu2;
	}
	/*public yonghu find(String userId,String pwd) throws Exception {
	    Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    yonghu stu2 = null;
	    try {
	       con=DbConnect.getDBconnection();
	       String sql = "select * from user_a where name=? and pwd=?";
            prepStmt = con.prepareStatement(sql);
            //prepStmt.setString(1, y.getName());
            prepStmt.setString(1, userId);
            prepStmt.setString(2, pwd);
            rs = prepStmt.executeQuery();
            
            if (rs.next()){
            	stu2 = new yonghu();
                stu2.setName(rs.getString(1)); 
                stu2.setPwd(rs.getString(2));
           }
      } catch (Exception e) {
          // handle exception
      } finally {
    	     DbConnect.closeDB(con, prepStmt, rs);
      }
     return stu2;
	}
    /*public userTable findUserById1(String userId,String pwd) throws Exception{
			Connection conn = null;
			PreparedStatement ps = null;
			ResultSet rs = null;
			userTable user=null;
			try {
				conn = JdbcUtil.getConnection();
				String sql = "select * from userlogin where username=? and password=? ";
				ps = conn.prepareStatement(sql);
				//System.out.print(userId);
				//System.out.print(pwd);
				ps.setString(1, userId);
				ps.setString(2, pwd);
				rs=ps.executeQuery();//ִ�в�ѯ,����һ��next������ResultSet���󣬳ɹ�����next������true ʧ�ܷ���next������false
				if(rs.next()){//
					user=new userTable();//�Ѳ�ѯ�������ݸ�ֵ��user������
				   user.setUsername(rs.getString(1));
				   
				   user.setPassword(rs.getString(2));
				}
			}finally {JdbcUtil.free(rs, ps, conn);}
			return user;//����
		   }*/
}
