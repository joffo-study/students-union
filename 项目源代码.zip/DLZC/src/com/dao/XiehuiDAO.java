package com.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.db.DbConnect;

import vo.Student;
import vo.Xiehui;
public class XiehuiDAO implements IXiehuiDAO {
	
 /*
	public Xiehui create(Xiehui stu) throws Exception{
		 Connection con=null;
	      PreparedStatement prepStmt=null;
	      ResultSet rs=null;
	      try{
	    	  con=DbConnect.getDBconnection();
	    	  prepStmt =con.prepareStatement(INSERT_SQL); 
	    	  prepStmt.setInt(1,stu.getId());
	    	  prepStmt.setString(2,stu.getBookname());
	    	  prepStmt.setString(3,stu. getAuthor());
	    	  prepStmt.setFloat(4,stu.getPrice());
	    	  prepStmt.setString(5,stu.getElsed());
	          prepStmt.executeUpdate();
	      } catch(Exception e){
	      } finally{
	    	     DbConnect.closeDB(con, prepStmt, rs);
	      }
	      return stu;
}
	public Xiehui find(Xiehui stu) throws Exception {
	    Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    Student stu2 = null;
	    try {
	       con=DbConnect.getDBconnection();
            prepStmt = con.prepareStatement(SELECT_SQL);
            prepStmt.setInt(1,stu.getId());
            rs = prepStmt.executeQuery();
            if (rs.next()){
            	stu2 = new Student();
                stu2.setId(rs.getInt(1)); 
                stu2.setBookname(rs.getString(2));
                stu2.setAuthor(rs.getString(3));
                stu2.setPrice(rs.getFloat(4)); 
                stu2.setElsed(rs.getString(5));
           }
      } catch (Exception e) {
          // handle exception
      } finally {
    	     DbConnect.closeDB(con, prepStmt, rs);
      }
     return stu2;
	}
   */
	public List<Xiehui> findAll() throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;	
	    List<Xiehui> student = new ArrayList<Xiehui>();
	    con=DbConnect.getDBconnection();
	    String sql="select Xname from xiehui";
	    prepStmt = con.prepareStatement(sql);
        rs = prepStmt.executeQuery();
        while(rs.next()) {
        	Xiehui stu2 = new Xiehui();
            stu2.setXname(rs.getString(1)); 
            
            student.add(stu2);
        }
        DbConnect.closeDB(con, prepStmt, rs); 
        return student;
	}
	public Xiehui findX(Xiehui y) throws Exception {
	       Connection conn=null;
	       PreparedStatement ps = null;
	       ResultSet rs=null;
	       Xiehui stu2 = null;
	       
	       try {
	        conn = DbConnect.getDBconnection();
	        String sql="select Xname,Bisai,Fengcai,Xid from xiehui where Xname=? or Bisai=？";
	        ps=conn.prepareStatement(sql);
	              ps.setString(1,y.getXname());
	              ps.setString(2,y.getBisai());
	              rs = ps.executeQuery();
	              
	              while (rs.next()){
	               stu2 = new Xiehui();
	               stu2.setXname(rs.getString(1));
	                  stu2.setBisai(rs.getString(2)); 
	                  stu2.setFengcai(rs.getString(3));
	                  stu2.setXid(rs.getInt(4));
	                 
	             }
	        } catch (Exception e) {
	            // handle exception
	        } finally {
	        	DbConnect.closeDB(conn, ps, rs);
	        }
	       return stu2;
	   }
	public List<Xiehui> findXQ(String xname) throws Exception {    //查询协会信息的详情内容
	       Connection conn=null;
	       PreparedStatement ps = null;
	       ResultSet rs=null;
	       Xiehui stu2 = null;
	       List<Xiehui> xiehui =new ArrayList<Xiehui>();
	       try {
	        conn = DbConnect.getDBconnection();
	        String sql="select Xname,Bisai,Fengcai,Xid from xiehui where Xname=?";
	        ps=conn.prepareStatement(sql);
	              ps.setString(1,xname);
	             
	              rs = ps.executeQuery();
	              
	              while (rs.next()){
	               stu2 = new Xiehui();
	                  stu2.setXname(rs.getString(1));
	                  stu2.setBisai(rs.getString(2)); 
	                  stu2.setFengcai(rs.getString(3));
	                  stu2.setXid(rs.getInt(4));
	                  xiehui.add(stu2);
	             }
	        } catch (Exception e) {
	            // handle exception
	        } finally {
	        	DbConnect.closeDB(conn, ps, rs);
	        }
	       return xiehui;
	   }
	/*public Xiehui find(Xiehui stu) throws Exception{
		Connection con=null;
		PreparedStatement prepStmt=null;
		ResultSet rs=null;
		Xiehui stu2=null;
		try{
			con=DbConnect.getDBconnection();
			String sql="select 协会ID,协会名称,协会风采,特色比赛 from xiehui where 协会ID=?";
			prepStmt=con.prepareStatement(sql);
	
			rs=prepStmt.executeQuery();
			if(rs.next())
			{
				stu2=new Xiehui();
				stu2.setId(rs.getInt(1));
				stu2.setMingcheng(rs.getString(2));
				stu2.setFengcai(rs.getString(3));
				stu2.setBisai(rs.getString(4));
				
			}
		}catch(Exception e){
		}finally{
			DbConnect.closeDB(con, prepStmt, rs);
		}
		return stu2;
	}*/
	

	public boolean removeX(String xname) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int n=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	String sql="delete from xiehui where Xname=? ";
	    	prepStmt = con.prepareStatement(sql);
	        prepStmt.setString(1,xname);
	        n=prepStmt.executeUpdate();
	    }catch(Exception e) {
	          
	    } finally{
	    	 DbConnect.closeDB(con, prepStmt, rs);
	    }if(n>=1) return true;
	    else return false;
	}
	
	public boolean removeXQ_F(String fengcai) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int n=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	String sql="delete from xiehui where Fengcai=? ";
	    	prepStmt = con.prepareStatement(sql);
	        prepStmt.setString(1,fengcai);
	        n=prepStmt.executeUpdate();
	    }catch(Exception e) {
	          
	    } finally{
	    	 DbConnect.closeDB(con, prepStmt, rs);
	    }if(n>=1) return true;
	    else return false;
	}

	public boolean updateXQ_B(Xiehui x) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int rowCount=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	String sql="update xiehui set Bisai=? where Xname=? and Bisai=? ";
         prepStmt = con.prepareStatement(sql);
            prepStmt.setString(1,x.getBisai());
            prepStmt.setString(2,x.getXname());
            prepStmt.setString(3,x.getBisai());
	    	
	    	rowCount=prepStmt.executeUpdate();
            if (rowCount == 0) {
                   throw new Exception("Update Error:Xiehui Bisai:" + x.getBisai());
            }
        } catch (Exception e) {
                e.printStackTrace();
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }if(rowCount!=0)  {return true;}
        else 
        	{ return false;}
    }
	public boolean updateXQ_F(Xiehui x) throws Exception {
		Connection con=null;
	    PreparedStatement prepStmt=null;
	    ResultSet rs=null;
	    int rowCount=0;
	    try {
	    	con=DbConnect.getDBconnection();
	    	String sql="update xiehui set Xname=?,Bisai=?,Fengcai=? where Xid=?";
            prepStmt = con.prepareStatement(sql);
            prepStmt.setString(1,x.getXname());
            prepStmt.setString(2,x.getBisai());
            prepStmt.setString(3,x.getFengcai());
            prepStmt.setInt(4,x.getXid());
           
	    	
	    	rowCount=prepStmt.executeUpdate();
            if (rowCount == 0) {
                   throw new Exception("Update Error:Xiehui Bisai:" + x.getFengcai());
            }
        } catch (Exception e) {
                e.printStackTrace();
        } finally {
        	 DbConnect.closeDB(con, prepStmt, rs);
        }if(rowCount!=0)  {return true;}
        else 
        	{ return false;}
    }
	/*	@Override
	public boolean remove(String xname) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}*/
	@Override
	public boolean remove(String xname) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean createX(Xiehui stu) throws Exception{
		Connection conn = null;
		 PreparedStatement ps = null;
		 ResultSet rs=null;
		 int count=0;

		 try {
			 conn = DbConnect.getDBconnection();
			 
			 String sql="insert into xiehui(Xname,Bisai,Fengcai) values(?,?,?)";
			 ps = conn.prepareStatement(sql);
			 
			 ps.setString(1,stu.getXname());
			 ps.setString(2,stu.getBisai());
			 ps.setString(3,stu.getFengcai());
			
			count=ps.executeUpdate();
			
		 }finally {DbConnect.closeDB(conn,ps,rs);}
		 if(count>0) return true;
		 else return false;
	   }
	
}