package vo;

public class Student {
	private int Sid;
	private String Sname;
	private String Shouji;
	private String Weixin;
	private String Xibie;
	
	private String Sduiwu;
	private String Sduixie;

	private String Zname;
	private String Zbumen;
	private String Zxiehui;
	
	

	
	public String getZname() {
		return Zname;
	}
	public void setZname(String zname) {
		this.Zname = zname;
	}
	
	public String getZbumen() {
		return Zbumen;
	}
	public void setZbumen(String zbumen) {
		this.Zbumen = zbumen;
	}
	
	public String getZxiehui() {
		return Zxiehui;
	}
	public void setZxiehui(String zxiehui) {
		this.Zxiehui = zxiehui;
	}
	
	public String getSduiwu() {
		return Sduiwu;
	}
	public void setSduiwu(String sduiwu) {
		this.Sduiwu = sduiwu;
	}
	public String getSduixie() {
		return Sduixie;
	}
	public void setSduixie(String sduixie) {
		this.Sduixie = sduixie;
	}
	
	
	
	public int getSid() {
		return Sid;
	}
	public void setSid(int sid) {
		this.Sid = sid;
	}
	
	public String getSname() {
		return Sname;
	}
	public void setSname(String sname) {
		this.Sname = sname;
	}
	
	
	
	public String getShouji() {
		return Shouji;
	}
	public void setShouji(String shouji) {
		this.Shouji = shouji;
	}
	
	public String getWeixin() {
		return Weixin;
	}
	public void setWeixin(String weixin) {
		this.Weixin = weixin;
	}
	
	public String getXibie() {
		return Xibie;
	}
	public void setXibie(String xibie) {
		this.Xibie = xibie;
	}
	

}
