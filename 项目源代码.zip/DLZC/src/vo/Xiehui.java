package vo;

public class Xiehui {
	private int Xid;
	private String Xname; 
	private String Fengcai;
	private String Bisai;
	
	
	public int getXid() {
		return Xid;
	}
	public void setXid(int xid) {
		this.Xid = xid;
	}
	
	public String getXname() {
		return Xname;
	}
	public void setXname(String xname) {
		this.Xname = xname;
	}
	public String getFengcai() {
		return Fengcai;
	}
	public void setFengcai(String fengcai) {
		this.Fengcai = fengcai;
	}
	public String getBisai() {
		return Bisai;
	}
	public void setBisai(String bisai) {
		this.Bisai = bisai;
	}
	
	
}

